import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

public class Calculate {
    /**
     * 计算器实现功能
     * addition, subtraction, multiplication  division, sqrt, undo, clear
     */

    //计算机栈
    Stack<String> stack = null;
    Stack<String> characterStack = null;
    int position = 0;
    String character = null;
    String stackResult = null;

    public Calculate() {
        stack = new Stack<String>();
        characterStack = new Stack<String>();
    }

    //addition
    public void addition() throws Exception {
//        position++;
        String right = popStack();
        String left = popStack();
        BigDecimal bigDecimal = new BigDecimal(left).add(new BigDecimal(right));
        pushStack(String.valueOf(bigDecimal));
    }

    //subtraction
    public void subtraction() throws Exception {
//        position++;
        String right = popStack();
        String left = popStack();
        BigDecimal bigDecimal = new BigDecimal(left).subtract(new BigDecimal(right));
        pushStack(String.valueOf(bigDecimal));
    }

    //multiplication
    public void multiplication() throws Exception {
        String right = popStack();
        String left = popStack();
        BigDecimal bigDecimal = new BigDecimal(left).multiply(new BigDecimal(right));
        pushStack(String.valueOf(bigDecimal));
    }

    //division
    public void division() throws Exception {
        String right = popStack();
        String left = popStack();
        BigDecimal bigDecimal = new BigDecimal(left).divide(new BigDecimal(right), 15, BigDecimal.ROUND_DOWN);
        bigDecimal=bigDecimal.stripTrailingZeros();
        pushStack(String.valueOf(bigDecimal));
    }

    //clear
    public void clearStack() {
        position = 0;
        character = null;
        stackResult = null;
        stack.clear();
        characterStack.clear();
    }

    //sqrt
    public void sqrt() throws Exception {
        String num = popStack();
        BigDecimal bigDecimal = new BigDecimal(Math.sqrt(Double.parseDouble(num)));
        pushStack(String.valueOf(bigDecimal));
    }

    // undo
    public void undo() throws Exception {
        if (!stack.empty()) {
            stack.pop();
        }
        undoMethod();
    }

    public void undoMethod() throws Exception {
        if (characterStack.empty()) {
            throw new Exception("栈未空，不能执行undo");
        }
        String string = characterStack.peek();
        characterStack.pop();
        if (string.equals("+") || string.equals("-") || string.equals("*") || string.equals("/")) {
            for (int i = characterStack.size() - 2; i < characterStack.size(); i++) {
                String character = characterStack.get(i);
                try {
                    Double.parseDouble(character);
                    stack.push(character);
                } catch (Exception e) {
                    StringBuffer sb = new StringBuffer();
                    for (int j = 0; j <= characterStack.size() - 2; j++) {
                        sb.append(characterStack.get(j)).append(" ");
                    }
                    resolve(sb.toString(), false);
                }
            }
        } else if (string.equals("sqrt")) {
            stack.push(characterStack.get(characterStack.size() - 1));
        } else if (string.equals("undo")) {
            undoMethod();
        } else if (string.equals("clear")) {
            characterStack.clear();
        } else {//number

        }
    }

    //向栈中添加元素
    public void pushStack(String num) {
        position++;//执行步骤自增
        stack.push(num);//添加元素
        stackResult = num;
    }

    //从栈中取除元素
    public String popStack() throws Exception {
        position++; //执行步骤自增
        if (stack.empty()) {//栈的非空验证
            throw new Exception("operator<" + character + ">（position:<" + position + ">）： insufficient parameters stack:" + stackResult);
        }
        String rs = stack.peek();
        stack.pop();
        return rs;
    }

    //处理用户输入信息
    public void resolve(String input, boolean flag) {
        try {
            String[] arr = input.split(" ");
            for (int i = 0; i < arr.length; i++) {
                character = arr[i];
                if (flag) {
                    characterStack.push(character);
                }
                switch (character) {
                    case "+":
                        addition();
                        break;
                    case "-":
                        subtraction();
                        break;
                    case "*":
                        multiplication();
                        break;
                    case "/":
                        division();
                        break;
                    case "clear":
                        clearStack();
                        break;
                    case "undo":
                        undo();
                        break;
                    case "sqrt":
                        sqrt();
                        break;
                    default:
                        try {
                            Double.parseDouble(character);
                        } catch (Exception e) {
                            throw new Exception("输入内容不能包含特殊字符：" + character);
                        }
                        pushStack(character);
                }
            }
            if (flag) {
                printStack();
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
            clearStack();

        }
    }

    //输出栈中信息
    public void printStack() {
        StringBuffer stringBuffer = new StringBuffer();
        if (stack.empty()) {
//            System.out.println("计算机栈为空");
            System.out.println("stack:");
            return;
        }
        for (int i = 0; i < stack.size(); i++) {
            String rs = stack.get(i);
            if (rs.contains(".") && rs.substring(rs.indexOf(".") + 1).length() >= 10) {
                rs = rs.substring(0, rs.indexOf(".") + 11);
            }
            stringBuffer.append(rs).append(" ");
        }
        System.out.println("stack:" + stringBuffer.toString());
    }
}
