import java.util.Scanner;

public class MyCalculator {

    //主方法
    public static void run() {
        Calculate calculator = new Calculate();
        System.out.println("请输入(字符间用空格间隔):");
        Scanner scanner = new Scanner(System.in);
        scanner.useDelimiter("\n");
        while (true) {
            String input = scanner.next();
            if ("".equals(input)) {
                continue;
            }
            calculator.resolve(input, true);
        }
    }

    public static void main(String[] args) {
        MyCalculator.run();
    }
}

