import org.junit.Test;

public class ExampleDemo {

    Calculate calculator = new Calculate();
    String input = null;

    @Test
    //Example1
    public void Example1() {
        input = "5 2";
        calculator.resolve(input, true);
    }

    @Test
    //Example2
    public void Example2() {
        input = "2 sqrt";
        calculator.resolve(input, true);
        input = "clear 9 sqrt";
        calculator.resolve(input, true);
    }

    @Test
    //Example3
    public void Example3() {
        input = "5 2 -";
        calculator.resolve(input, true);
        input = "3 -";
        calculator.resolve(input, true);
        input = "clear";
        calculator.resolve(input, true);
    }

    @Test
    //Example4
    public void Example4() {
        input = "5 4 3 2";
        calculator.resolve(input, true);
        input = "undo undo *";
        calculator.resolve(input, true);
        input = "5 *";
        calculator.resolve(input, true);
        input = "undo";
        calculator.resolve(input, true);
    }

    @Test
    //Example5
    public void Example5() {
        input = "7 12 2 /";
        calculator.resolve(input, true);
        input = "*";
        calculator.resolve(input, true);
        input = "4 /";
        calculator.resolve(input, true);
    }

    @Test
    //Example6
    public void Example6() {
        input = "1 2 3 4 5";
        calculator.resolve(input, true);
        input = "*";
        calculator.resolve(input, true);
        input = "clear 3 4 -";
        calculator.resolve(input, true);
    }

    @Test
    //Example7
    public void Example7() {
        input = "1 2 3 4 5";
        calculator.resolve(input, true);
        input = "* * * *";
        calculator.resolve(input, true);
    }

    @Test
    //Example8
    public void Example8() {
        input = "1 2 3 * 5 + * * 6 5";
        calculator.resolve(input, true);
    }
}
